# Onix Connect 2023 — projeto inicial

Este é um **projeto-fonte inicial**, não um APK pronto. Ele implementa a base de um aplicativo de mídia Android usando AndroidX Media3, com uma biblioteca de áudio local destinada à experiência de mídia do Android Auto.

## O que está incluído
- Projeto Android em Kotlin.
- Serviço MediaLibraryService com ExoPlayer/MediaLibrarySession.
- Consulta às músicas locais do dispositivo via MediaStore.
- Declaração da categoria `media` para Android Auto.
- Identificador do aplicativo: `br.com.onixconnect`.

## O que ainda falta antes de usar no carro
1. Criar uma tela no celular para solicitar a permissão de acesso às músicas. Sem essa permissão, a biblioteca retorna vazia.
2. Testar e corrigir a compilação no ambiente Android/Gradle.
3. Adicionar ícone, testes e tratamento de erros.
4. Validar o aplicativo com o Desktop Head Unit/Android Auto e cumprir as regras atuais de distribuição e qualidade do Google.
5. Spotify e YouTube Music **não são incorporados ao aplicativo**. O usuário abre os aplicativos oficiais, que aparecem no Android Auto se instalados e compatíveis.
6. Google Maps e Waze continuam sendo aplicativos de navegação independentes.

## Requisitos de compilação
- JDK 17
- Android SDK Platform 35
- Android Gradle Plugin 8.7.3
- Gradle compatível com AGP 8.7.3

Abra a pasta no Android Studio ou configure um ambiente Gradle na nuvem. Gere o APK de depuração com:

```bash
gradle assembleDebug
```

Saída esperada após compilação bem-sucedida:
`app/build/outputs/apk/debug/app-debug.apk`

## Observação importante
A declaração de serviço e a categoria de mídia são a base técnica, não uma garantia de aprovação ou de funcionamento em todo veículo. A compatibilidade final depende da versão do Android Auto, do telefone, da central multimídia e da validação do aplicativo.
